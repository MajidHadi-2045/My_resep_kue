package com.resep.mymenu_resep_kue;

import android.app.Activity;

public class detailKue extends Activity {
}


